#include<stdio.h>
int n=0;
int num1=0,num2=0;
int add();
int subtract();
int multiply();
int divide();
int analysis(){
    printf("Continue:");
    scanf("%d",&n);
    while(n>4){
        printf("Wrong option!\n");
        return analysis();
    }
    if(n==1){
        add();
    }else if(n==2){
        subtract();
    }else if(n==3){
        multiply();
    }else if(n==4){
        divide();
    }
    return analysis();
}
int  add(){
    printf("Type two numbers that you want to add by using space:");
    scanf("%d",&num1);
    scanf("%d",&num2);
    int t=0;
    t=num1+num2;
    printf("Answer:%d+%d=%d\n\n",num1,num2,t);
    return 0;
}
int subtract(){
    printf("Type two numbers that you want to subtract by using space:");
    scanf("%d",&num1);
    scanf("%d",&num2);
    int u=0;
    u=num1-num2;
    printf("Answer:%d-%d=%d\n\n",num1,num2,u);
    return 0;
}
int multiply(){
    printf("Type two numbers that you want to multiply by using space:");
    scanf("%d",&num1);
    scanf("%d",&num2);
    int r=0;
    r=num1*num2;
    printf("Answer:%d*%d=%d\n\n",num1,num2,r);
    return 0;
}
int divide(){
    printf("Type two numbers that you want to divide by using space:");
    scanf("%d",&num1);
    scanf("%d",&num2);
    int k=0;
    int remainder=0;
    k=num1/num2;
    remainder=num1%num2;
    printf("Answer:%d/%d=%d\nRemainder=%d\n\n",num1,num2,k,remainder);
    return 0;
}
int main(){
    printf("Hi,I'm calculator\nSo,If you want Addition type 1\nIf you want Subtraction type 2\nIf you want Multiplying type 3\nIf you want Dividing type    4\n");
    analysis();
    return analysis();
}
