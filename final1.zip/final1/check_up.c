#include<stdio.h>
int kyawGyi();
int suSu();
int hlaHla();
int k[18];
int i=0;
int total[3];
int main(){
    int b=0,d=0,f=0;
    printf("Sorry,I know you said that to pre define data but I want to collect data from user.\nSo,let's Continue......\n");
    kyawGyi();
    suSu();
    hlaHla();
for(int a=1;a<3;a++){
    if(total[0]>total[a]){
   b++;
    }
}
if(b==2){
    printf("The total marks of Kyaw Gyi is the highest.");
}
for(int c=0;c<3;c++){
    if(total[1]>total[c]){
        d++;
    }
}
if(d==2){
    printf("The total marks of Su Su is the highest.");
}
for(int e=0;e<3;e++){
    if(total[2]>total[e]) {
        f++;
    }
}
if(f==2){
    printf("The total marks of Hla Hla is the highest.");
}
    printf("\n\n");
    return 0;
}
int kyawGyi(){
    int subject=0;
    int distinction=0;
    for(i=0;i<6;i++){
        printf("Enter Kyaw Gyi's marks for each subjects in 100 marks Final Examination:'subject %d':",i+1);
        scanf("%d",&k[i]);
        total[0]=k[i]+total[0];
        if(k[i]<40){
            subject++;
        }
        if(k[i]>=80){
            distinction++;
        }
    }
    printf("\n");
    if(subject==0){
        printf("Congratulation,your student Kyaw Gyi Pass Final Examination with the total marks of %d and\n",total[0]);
    }
    else{
        printf("Sorry, your student Kyaw Gyi fail Final Examination with the total of %d subject and total marks of %d but\n",subject,total[0]);
    }
    if(distinction==0){
        printf("Kyaw Gyi has no distinction in any subjects.");
    }else{
        printf("Congratulation,Your student Kyaw Gyi has %d distinction.",distinction);
    }
    printf("\n\n\n");
    return 0;
}
int suSu(){
    int subject=0;
    int distinction=0;
    for(i=6;i<12;i++){
        printf("Enter Su Su's marks for each subjects in 100 marks Final Examination:'subject %d':",(i-6)+1);
        scanf("%d",&k[i]);
        total[1]=k[i]+total[1];
        if(k[i]<40){
            subject++;
        }
        if(k[i]>=80){
            distinction++;
        }
    }printf("\n");
    if(subject==0){
        printf("Congratulation,your student Su Su Pass Final Examination with the total marks of %d and\n",total[1]);
    }
    else{
        printf("Sorry, your student Su Su fail Final Examination with the total of %d subject and total marks of %d but\n",subject,total[1]);
    }
    if(distinction==0){
        printf("Su Su has no distinction in any subjects.");
    }else{
        printf("Congratulation,Your student Su Su has %d distinction.",distinction);
    }
    printf("\n\n\n");
    return 0;
}

int hlaHla(){
    int distinction=0;
    int subject=0;
    for(i=12;i<=17;i++) {
        printf("Enter Hla Hla's marks for each subjects in 100 marks Final Examination:'subject %d':", (i - 12) + 1);
        scanf("%d", &k[i]);
        total[2] = k[i] + total[2];
        if (k[i] < 40) {
            subject++;
        }if(k[i]>=80){
            distinction++;
        }
    }printf("\n");
    if(subject==0){
        printf("Congratulation,your student Hla Hla Pass Final Examination with the total marks of %d and\n",total[2]);
    }
    else{
        printf("Sorry, your student Hla Hla fail Final Examination with the total of %d subject and total marks of %d but\n",subject,total[2]);
    }
    if(distinction==0){
        printf("Hla Hla has no distinction in any subjects.\n\n");
    }else{
        printf("Congratulation,Your student Hla Hla has %d distinction.\n\n",distinction);
    }
    return 0;
}